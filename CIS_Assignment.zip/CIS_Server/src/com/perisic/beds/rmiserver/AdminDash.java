package com.perisic.beds.rmiserver;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import java.lang.System.Logger;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.RemoteServer;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;

import com.perisic.beds.peripherals.EditQuestion;
import com.perisic.beds.peripherals.MainDash;
import com.perisic.beds.peripherals.ViewFeedback;
import com.perisic.beds.rmiinterface.RemoteQuestions;


public class AdminDash extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1130033892317089076L;
	protected static final AbstractButton errorStatus = null;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminDash frame = new AdminDash();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AdminDash() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 1056, 650);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(new Color(100, 149, 237));
		panel.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel.setForeground(new Color(0, 0, 139));
		panel.setBounds(0, 0, 1040, 611);
		contentPane.add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(0, 0, 139));
		panel_1.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel_1.setBackground(new Color(100, 149, 237));
		panel_1.setBounds(21, 27, 998, 87);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel headlbl = new JLabel("Hello Admin, Welcome back!");
		headlbl.setFont(new Font("Comic Sans MS", Font.BOLD | Font.ITALIC, 40));
		headlbl.setBounds(215, 11, 560, 58);
		panel_1.add(headlbl);

		JPanel panel_1_1 = new JPanel();
		panel_1_1.setForeground(new Color(0, 0, 139));
		panel_1_1.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel_1_1.setBackground(new Color(100, 149, 237));
		panel_1_1.setBounds(21, 160, 348, 429);
		panel.add(panel_1_1);
		panel_1_1.setLayout(null);

		JButton btnQuestionnaire = new JButton("Questionnaire");
		btnQuestionnaire.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnQuestionnaire.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				EditQuestion q = new EditQuestion();
				q.setVisible(true);
				q.setLocationRelativeTo(null);
				q.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				AdminDash.this.dispose();
			}
		});
		btnQuestionnaire.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnQuestionnaire.setBounds(64, 274, 231, 45);
		panel_1_1.add(btnQuestionnaire);

		JLabel lblNewLabel_1 = new JLabel("SERVER");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(32, 32, 78, 26);
		panel_1_1.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("DATABASE");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1_1.setBounds(30, 233, 102, 26);
		panel_1_1.add(lblNewLabel_1_1);

		JButton btnViewFeedback = new JButton("View Feedback");
		btnViewFeedback.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ViewFeedback fdb = new ViewFeedback();
				fdb.setVisible(true);
				fdb.setLocationRelativeTo(null);
				fdb.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				AdminDash.this.dispose();
			}
		});
		btnViewFeedback.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnViewFeedback.setBounds(51, 346, 258, 45);
		panel_1_1.add(btnViewFeedback);

		JButton btnStartServer = new JButton("Start Server");
		btnStartServer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					RemoteQuestions questions = new QuestionServerImplementation();
					Registry reg = LocateRegistry.createRegistry(1066);
					try {
						reg.rebind("QuestionService1819",questions);
						errorStatus.setText("Server started successfully");

					} catch (RemoteException e1) {
						Logger.getLogger(RemoteServer.class.getName()).log(Level.SEVERE,null,e1); 
						e1.printStackTrace();
					}

				} catch(Exception e1) {
					String errormessage = "An Error occured: " +e1.toString();

					errorStatus.setText(errormessage);
					e1.printStackTrace();
				}
			}
		});
		btnStartServer.setFont(new Font("Tahoma", Font.PLAIN, 30));
		btnStartServer.setBounds(75, 69, 203, 45);
		panel_1_1.add(btnStartServer);

		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setForeground(new Color(0, 0, 139));
		panel_1_1_1.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 139)));
		panel_1_1_1.setBackground(new Color(100, 149, 237));
		panel_1_1_1.setBounds(379, 160, 640, 429);
		panel.add(panel_1_1_1);

		JButton btnBack = new JButton("Back");
		btnBack.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				MainDash fdb = new MainDash();
				fdb.setVisible(true);
				fdb.setLocationRelativeTo(null);
				fdb.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				AdminDash.this.dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnBack.setBounds(31, 125, 88, 27);
		panel.add(btnBack);
	}

}

